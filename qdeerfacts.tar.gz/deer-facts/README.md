# qdeer-facts
A silly program that generates real facts about deers.

Based off [sex.c](http://spatula.net/software/sex/)
The original author of sex.c is unknown. If you are the original author, or know who is, contact <qmaury@goat.si> or <freebsd@spatula.net>.

The original sex.c program is presumably BSD licensed or in the public domain, but we're not fully sure. Hopefully I'm not breaking any laws here.
